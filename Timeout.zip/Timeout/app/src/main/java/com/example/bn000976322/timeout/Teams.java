package com.example.bn000976322.timeout;

public class Teams {

    int teamsImage;
    int teamsName;
    int teamsFoundedDate;
    int teamsHeadCoach;
    int teamsStadium;
    int teamsHistory;
    int teamsPhotoOne;
    int teamsPhotoTwo;
    int teamsPhotoThree;
    int teamsPhotoFour;
    int teamsPhotoFive;

    public int getTeamsPhotoFour() {
        return teamsPhotoFour;
    }

    public void setTeamsPhotoFour(int teamsPhotoFour) {
        this.teamsPhotoFour = teamsPhotoFour;
    }

    public int getTeamsPhotoFive() {
        return teamsPhotoFive;
    }

    public void setTeamsPhotoFive(int teamsPhotoFive) {
        this.teamsPhotoFive = teamsPhotoFive;
    }

    public int getTeamsPhotoOne() {
        return teamsPhotoOne;
    }

    public void setTeamsPhotoOne(int teamsPhotoOne) {
        this.teamsPhotoOne = teamsPhotoOne;
    }

    public int getTeamsPhotoTwo() {
        return teamsPhotoTwo;
    }

    public void setTeamsPhotoTwo(int teamsPhotoTwo) {
        this.teamsPhotoTwo = teamsPhotoTwo;
    }

    public int getTeamsPhotoThree() {
        return teamsPhotoThree;
    }

    public void setTeamsPhotoThree(int teamsPhotoThree) {
        this.teamsPhotoThree = teamsPhotoThree;
    }

    public int getTeamsHistory() {
        return teamsHistory;
    }

    public void setTeamsHistory(int teamsHistory) {
        this.teamsHistory = teamsHistory;
    }

    public int getTeamsFoundedDate() {
        return teamsFoundedDate;
    }

    public void setTeamsFoundedDate(int teamsFoundedDate) {
        this.teamsFoundedDate = teamsFoundedDate;
    }

    public int getTeamsHeadCoach() {
        return teamsHeadCoach;
    }

    public void setTeamsHeadCoach(int teamsHeadCoach) {
        this.teamsHeadCoach = teamsHeadCoach;
    }

    public int getTeamsStadium() {
        return teamsStadium;
    }

    public void setTeamsStadium(int teamsStadium) {
        this.teamsStadium = teamsStadium;
    }

    public int getTeamsImage() {
        return teamsImage;
    }

    public void setTeamsImage(int teamsImage) {
        this.teamsImage = teamsImage;
    }

    public int getTeamsName() {
        return teamsName;
    }

    public void setTeamsName(int teamsName) {
        this.teamsName = teamsName;
    }

}
