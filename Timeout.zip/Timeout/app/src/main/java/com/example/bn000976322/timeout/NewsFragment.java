package com.example.bn000976322.timeout;


import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class NewsFragment extends Fragment{

    ListView lv_news;
    ArrayList<News> newsList;

    public NewsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_news, container, false);
        newsList = new ArrayList<>();
        insertData();
        NewsAdapter newsAdapter = new NewsAdapter(getActivity().getBaseContext(), newsList);
        lv_news = (ListView)view.findViewById(R.id.lv_news);
        lv_news.setAdapter(newsAdapter);

        lv_news.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                int currImage = newsList.get(position).getNewsImage();
                int currTitle = newsList.get(position).getNewsTitle();
                int currDesc = newsList.get(position).getNewsDescription();

                Intent i = new Intent(getContext(),DetailNewsActivity.class);
                i.putExtra("newsImage",currImage);
                i.putExtra("newsTitle",currTitle);
                i.putExtra("newsDesc",currDesc);
                startActivity(i);

            }
        });

        return view;
    }

    public void insertData(){
        newsList.add(new News(R.drawable.news_1, R.string.news_title_one, R.string.upload_title_one, R.string.description_one));
        newsList.add(new News(R.drawable.news_2, R.string.news_title_two, R.string.upload_title_two, R.string.description_two));
        newsList.add(new News(R.drawable.news_3, R.string.news_title_three, R.string.upload_title_three, R.string.description_three));
    }


}
