package com.example.bn000976322.timeout;

public class Standings {
    int teamRank;
    int teamLogo;
    int teamName;
    int teamWin;
    int teamLoss;

    public int getTeamRank() {
        return teamRank;
    }

    public void setTeamRank(int teamRank) {
        this.teamRank = teamRank;
    }

    public int getTeamLogo() {
        return teamLogo;
    }

    public void setTeamLogo(int teamLogo) {
        this.teamLogo = teamLogo;
    }

    public int getTeamName() {
        return teamName;
    }

    public void setTeamName(int teamName) {
        this.teamName = teamName;
    }

    public int getTeamWin() {
        return teamWin;
    }

    public void setTeamWin(int teamWin) {
        this.teamWin = teamWin;
    }

    public int getTeamLoss() {
        return teamLoss;
    }

    public void setTeamLoss(int teamLoss) {
        this.teamLoss = teamLoss;
    }
}
