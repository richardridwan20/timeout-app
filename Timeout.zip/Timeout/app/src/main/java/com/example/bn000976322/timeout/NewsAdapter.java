package com.example.bn000976322.timeout;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class NewsAdapter extends ArrayAdapter<News> {

    ArrayList<News> newsList;
    Context context;

    public NewsAdapter(@NonNull Context context,ArrayList<News> newsList) {
        super(context, 0,newsList);
        this.context = context;
        this.newsList = newsList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView == null){
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            convertView = inflater.inflate(R.layout.news_item,parent,false);
        }

        News currPos = this.newsList.get(position);

        ImageView cardImage = convertView.findViewById(R.id.img_one);
        cardImage.setImageResource(currPos.getNewsImage());

        TextView cardTitle = convertView.findViewById(R.id.title_one);
        cardTitle.setText(currPos.getNewsTitle());

        TextView cardUpload = convertView.findViewById(R.id.upload_one);
        cardUpload.setText(currPos.getNewsUpload());

        return convertView;
    }
}
