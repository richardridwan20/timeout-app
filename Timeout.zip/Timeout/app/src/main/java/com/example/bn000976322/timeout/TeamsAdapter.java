package com.example.bn000976322.timeout;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class TeamsAdapter extends ArrayAdapter<Teams> {

    ArrayList<Teams> teamsList;
    Context context;

    public TeamsAdapter(@NonNull Context context, ArrayList<Teams> teamsList) {
        super(context, 0, teamsList);
        this.context = context;
        this.teamsList = teamsList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null){
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            convertView = inflater.inflate(R.layout.teams_item, parent, false);
        }

        Teams currTeam = this.teamsList.get(position);

        ImageView teamsImage = convertView.findViewById(R.id.img_teams);
        teamsImage.setImageResource(currTeam.getTeamsImage());

        TextView teamsName = convertView.findViewById(R.id.tv_teams);
        teamsName.setText(currTeam.getTeamsName());

        return convertView;
    }
}
